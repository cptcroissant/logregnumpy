from setuptools import setup

setup(name='logregnumpy',
      version='0.1.0',
      description='Logistic regression classifier',
      packages=['logregnumpy'],
      author_email='kir.klyukvin@gmail.com',
      zip_safe=False)
